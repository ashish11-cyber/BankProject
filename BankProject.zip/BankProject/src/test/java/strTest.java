import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class strTest {

    @BeforeEach
    void setUp() {
    }
}