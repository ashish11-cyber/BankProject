public interface str {
}
